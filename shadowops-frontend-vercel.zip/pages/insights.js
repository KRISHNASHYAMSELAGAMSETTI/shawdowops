
export default function Insights() {
  return (
    <div style={{ padding: "2rem" }}>
      <h2>Insights</h2>
      <p>AI-driven feedback will appear here.</p>
    </div>
  );
}
