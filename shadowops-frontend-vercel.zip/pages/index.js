
export default function Home() {
  return (
    <div style={{ padding: "2rem" }}>
      <h1>ShadowOps AI</h1>
      <p>Your autonomous co-founder for launching micro-SaaS products.</p>
    </div>
  );
}
